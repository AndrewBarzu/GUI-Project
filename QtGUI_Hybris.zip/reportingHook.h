#pragma once

#if defined(WIN32)
void setFilterDebugHook(void);
#endif