# GUI-Project
This is a GUI project made in c++ with Qt in Windows Visual Studio

As the description says it all, this is a C++ GUI project which allows adding, removing, deleting and updating elements in a list.
It features multiple repository types, from non-persistent in memory allocation to csv and db repositories. It also contains a
"favorites" list, a chart for displaying some statistics and two separate windows that are made using the MVC pattern.
